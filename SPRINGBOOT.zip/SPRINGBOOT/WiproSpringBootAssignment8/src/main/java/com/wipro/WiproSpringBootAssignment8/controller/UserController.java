package com.wipro.WiproSpringBootAssignment8.controller;

import org.springframework.web.bind.annotation.*;
import com.wipro.WiproSpringBootAssignment8.model.User;

@RestController
@RequestMapping("/users")
public class UserController {

    @PostMapping
    public String createUser(@RequestBody User user) {
        return "User Created: " + user.getFirstName() + " " + user.getLastName() + ", Age: " + user.getAge();
    }
}
