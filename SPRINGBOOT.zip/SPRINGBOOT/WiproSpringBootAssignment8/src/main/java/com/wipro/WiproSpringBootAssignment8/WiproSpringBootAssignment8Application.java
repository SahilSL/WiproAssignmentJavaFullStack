package com.wipro.WiproSpringBootAssignment8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment8Application {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment8Application.class, args);
    }
}
