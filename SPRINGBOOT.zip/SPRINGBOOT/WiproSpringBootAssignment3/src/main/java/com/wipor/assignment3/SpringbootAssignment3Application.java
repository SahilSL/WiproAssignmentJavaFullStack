package com.wipor.assignment3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAssignment3Application {
    public static void main(String[] args) {
        SpringApplication.run(SpringbootAssignment3Application.class, args);
    }
}
