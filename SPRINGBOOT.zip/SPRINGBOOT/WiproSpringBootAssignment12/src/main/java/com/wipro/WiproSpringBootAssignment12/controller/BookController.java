package com.wipro.WiproSpringBootAssignment12.controller;

import com.wipro.WiproSpringBootAssignment12.model.Book;
import com.wipro.WiproSpringBootAssignment12.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
public class BookController {

    @Autowired
    private BookRepository bookRepository;

    @GetMapping("/springjdbc/books")
    public List<Book> getBooks() {
        return bookRepository.findAll();
    }
}
