package com.wipro.WiproSpringBootAssignment12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment12Application {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment12Application.class, args);
    }
}
//http://localhost:8080/springjdbc/books //fetch