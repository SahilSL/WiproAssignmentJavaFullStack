package com.wipro.WiproSpringBootAssignment12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproSpringBootAssignment12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
