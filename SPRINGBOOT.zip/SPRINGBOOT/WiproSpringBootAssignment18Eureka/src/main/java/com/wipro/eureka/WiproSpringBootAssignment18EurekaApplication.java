package com.wipro.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class WiproSpringBootAssignment18EurekaApplication {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment18EurekaApplication.class, args);
    }
}

// http://localhost:8761/

//pstman http://localhost:8081/restaurants
// http://localhost:8082/consumer/restaurants