package com.wipro.wsa18.WiproSpringBootAssignment18Eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproSpringBootAssignment18EurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
