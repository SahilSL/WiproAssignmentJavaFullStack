package com.wipro.controller;

import com.wipro.model.Ride;
import com.wipro.service.RideProducerService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/rides")
public class RideController {

    private final RideProducerService rideProducerService;

    public RideController(RideProducerService rideProducerService) {
        this.rideProducerService = rideProducerService;
    }

    @PostMapping
    public String createRide(@RequestBody Ride ride) {
        ride.setOperation("CREATE");
        rideProducerService.sendRideMessage(ride);
        return "Ride creation request sent to Kafka.";
    }

    @PutMapping("/{id}")
    public String updateRide(@PathVariable Long id, @RequestBody Ride ride) {
        ride.setOperation("UPDATE");
        ride.setId(id);
        rideProducerService.sendRideMessage(ride);
        return "Ride update request sent to Kafka.";
    }

    @DeleteMapping("/{id}")
    public String deleteRide(@PathVariable Long id) {
        Ride ride = new Ride();
        ride.setOperation("DELETE");
        ride.setId(id);
        rideProducerService.sendRideMessage(ride);
        return "Ride delete request sent to Kafka.";
    }
}
