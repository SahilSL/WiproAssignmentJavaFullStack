package com.wipro.UberRideConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UberRideConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
