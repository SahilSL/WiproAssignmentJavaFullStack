package com.wipro.consumer.controller;

import com.wipro.consumer.entity.Ride;
import com.wipro.consumer.repository.RideRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/rides")
public class RideController {

    private final RideRepository rideRepository;

    public RideController(RideRepository rideRepository) {
        this.rideRepository = rideRepository;
    }

    @GetMapping
    public List<Ride> getAll() {
        return rideRepository.findAll();
    }

    @GetMapping("/{id}")
    public Object getById(@PathVariable Long id) {
        Optional<Ride> r = rideRepository.findById(id);
        return r.orElseThrow();
    }
}
