package com.wipro.consumer.listener;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.consumer.entity.Ride;
import com.wipro.consumer.repository.RideRepository;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RideKafkaListener {

    private final RideRepository rideRepository;
    private final ObjectMapper mapper = new ObjectMapper();

    public RideKafkaListener(RideRepository rideRepository) {
        this.rideRepository = rideRepository;
    }

    @KafkaListener(topics = "${app.topic.name}", groupId = "${spring.kafka.consumer.group-id}")
    public void listen(String message) {
        try {
            JsonNode node = mapper.readTree(message);
            String operation = node.path("operation").asText();
            long id = node.path("id").asLong();

            switch (operation.toUpperCase()) {
                case "CREATE":
                    Ride newRide = new Ride();
                    newRide.setId(id);
                    newRide.setDriverName(node.path("driverName").asText(null));
                    newRide.setPassengerName(node.path("passengerName").asText(null));
                    newRide.setPickupLocation(node.path("pickupLocation").asText(null));
                    newRide.setDropLocation(node.path("dropLocation").asText(null));
                    if (node.has("fare") && !node.get("fare").isNull()) newRide.setFare(node.get("fare").asDouble());
                    rideRepository.save(newRide);
                    break;

                case "UPDATE":
                    Optional<Ride> opt = rideRepository.findById(id);
                    if (opt.isPresent()) {
                        Ride exist = opt.get();
                        if (node.hasNonNull("driverName")) exist.setDriverName(node.get("driverName").asText());
                        if (node.hasNonNull("passengerName")) exist.setPassengerName(node.get("passengerName").asText());
                        if (node.hasNonNull("pickupLocation")) exist.setPickupLocation(node.get("pickupLocation").asText());
                        if (node.hasNonNull("dropLocation")) exist.setDropLocation(node.get("dropLocation").asText());
                        if (node.hasNonNull("fare")) exist.setFare(node.get("fare").asDouble());
                        rideRepository.save(exist);
                    } else {
                        // If update for non-existing id — create new (optional)
                        Ride r = new Ride();
                        r.setId(id);
                        r.setDriverName(node.path("driverName").asText(null));
                        r.setPassengerName(node.path("passengerName").asText(null));
                        r.setPickupLocation(node.path("pickupLocation").asText(null));
                        r.setDropLocation(node.path("dropLocation").asText(null));
                        if (node.has("fare") && !node.get("fare").isNull()) r.setFare(node.get("fare").asDouble());
                        rideRepository.save(r);
                    }
                    break;

                case "DELETE":
                    rideRepository.deleteById(id);
                    break;

                default:
                    // ignore unknown operations
                    break;
            }
        } catch (Exception e) {
            System.err.println("Failed to process message: " + message);
            e.printStackTrace();
        }
    }
}
