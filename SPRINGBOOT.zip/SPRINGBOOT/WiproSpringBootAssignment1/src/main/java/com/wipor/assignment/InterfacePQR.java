package com.wipor.assignment;

public interface InterfacePQR {
    void display();
}
