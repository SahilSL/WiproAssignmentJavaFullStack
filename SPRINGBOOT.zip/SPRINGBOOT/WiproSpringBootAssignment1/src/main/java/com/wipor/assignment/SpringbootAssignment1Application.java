package com.wipor.assignment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAssignment1Application implements CommandLineRunner {

    @Autowired
    ClassKLM klm;

    public static void main(String[] args) {
        SpringApplication.run(SpringbootAssignment1Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        klm.show();
    }
}
