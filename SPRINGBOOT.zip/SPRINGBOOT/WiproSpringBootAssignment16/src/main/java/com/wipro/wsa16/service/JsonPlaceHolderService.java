package com.wipro.wsa16.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class JsonPlaceHolderService {

    private static final String BASE_URL = "https://jsonplaceholder.typicode.com/posts";

    @Autowired
    private RestTemplate restTemplate;

    public Object getAllPosts() {
        return restTemplate.getForObject(BASE_URL, Object.class);
    }

    public Object getPostById(int id) {
        return restTemplate.getForObject(BASE_URL + "/" + id, Object.class);
    }

    public Object createPost(Object post) {
        return restTemplate.postForObject(BASE_URL, post, Object.class);
    }

    public Object updatePost(int id, Object post) {
        HttpEntity<Object> requestUpdate = new HttpEntity<>(post);
        ResponseEntity<Object> response = restTemplate.exchange(BASE_URL + "/" + id, HttpMethod.PUT, requestUpdate, Object.class);
        return response.getBody();
    }

    public String deletePost(int id) {
        restTemplate.delete(BASE_URL + "/" + id);
        return "Post with ID " + id + " deleted";
    }
}
