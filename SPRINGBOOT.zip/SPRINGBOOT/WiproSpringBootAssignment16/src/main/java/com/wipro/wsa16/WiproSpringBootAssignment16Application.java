package com.wipro.wsa16;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment16Application {

	public static void main(String[] args) {
		SpringApplication.run(WiproSpringBootAssignment16Application.class, args);
	}

}

/*
GET: http://localhost:8080/posts http://localhost:8080/posts/1
POSt : http://localhost:8080/posts
{
  "title": "Data SCiecne 101",
  "body": "Intor to DS",
  "userId": 157
}

PUT: http://localhost:8080/posts/1
{
  "id": 1,
  "title": "New DS 201",
  "body": "Intermediate DS",
  "userId": 1
}

DELETE: http://localhost:8080/posts/1
 */
 