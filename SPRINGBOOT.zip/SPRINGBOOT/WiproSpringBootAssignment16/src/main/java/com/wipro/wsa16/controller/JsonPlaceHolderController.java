
package com.wipro.wsa16.controller;

import com.wipro.wsa16.service.JsonPlaceHolderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/posts")
public class JsonPlaceHolderController {

    @Autowired
    private JsonPlaceHolderService service;

    @GetMapping
    public Object getAllPosts() {
        return service.getAllPosts();
    }

    @GetMapping("/{id}")
    public Object getPost(@PathVariable int id) {
        return service.getPostById(id);
    }

    @PostMapping
    public Object createPost(@RequestBody Object post) {
        return service.createPost(post);
    }

    @PutMapping("/{id}")
    public Object updatePost(@PathVariable int id, @RequestBody Object post) {
        return service.updatePost(id, post);
    }

    @DeleteMapping("/{id}")
    public String deletePost(@PathVariable int id) {
        return service.deletePost(id);
    }
}
