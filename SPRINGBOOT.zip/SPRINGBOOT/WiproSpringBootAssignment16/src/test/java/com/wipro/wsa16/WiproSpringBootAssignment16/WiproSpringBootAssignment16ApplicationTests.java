package com.wipro.wsa16.WiproSpringBootAssignment16;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproSpringBootAssignment16ApplicationTests {

	@Test
	void contextLoads() {
	}

}
