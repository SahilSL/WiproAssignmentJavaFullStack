package com.wipro.WiproSpringBootAssignment11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment11Application {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment11Application.class, args);
    }
}
//http://localhost:8080/springrest/
//http://localhost:8080/springrest/customers