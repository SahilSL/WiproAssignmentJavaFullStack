package com.wipro.producer.controller;

import com.wipro.producer.model.Restaurant;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
public class RestaurantController {

    @GetMapping("/restaurants")
    public List<Restaurant> getRestaurants() {
        return List.of(
                new Restaurant(1L, "REs 1", "Nagpur"),
                new Restaurant(2L, "REs 2", "Pune"),
                new Restaurant(3L, "REs 3", "Mumbai")
        );
    }
}
