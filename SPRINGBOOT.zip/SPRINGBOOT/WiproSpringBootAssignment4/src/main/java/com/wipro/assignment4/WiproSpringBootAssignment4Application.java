package com.wipro.assignment4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment4Application {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment4Application.class, args);
    }
}

//pm
// http://localhost:8080/users/101/accounts?type=current&status=active
//http://localhost:8080/users/102/accounts?type=current&status=inactive