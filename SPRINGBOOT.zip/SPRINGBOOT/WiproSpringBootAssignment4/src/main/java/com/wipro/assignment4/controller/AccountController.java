package com.wipro.assignment4.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
public class AccountController {

    @GetMapping("/users/{id}/accounts")
    public List<String> getAccounts(
            @PathVariable String id,
            @RequestParam String type,
            @RequestParam String status) {

        List<String> accounts = Arrays.asList(
                "Account 1: ID=" + id + ", Type=" + type + ", Status=" + status,
                "Account 2: ID=" + id + ", Type=" + type + ", Status=" + status
        );
        return accounts;
    }
}
