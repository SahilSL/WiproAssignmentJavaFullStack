package com.wipro.assignment4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproSpringBootAssignment4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
