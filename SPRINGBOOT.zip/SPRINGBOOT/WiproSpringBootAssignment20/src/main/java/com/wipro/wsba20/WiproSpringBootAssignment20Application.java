package com.wipro.wsba20;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment20Application {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment20Application.class, args);
    }
}

//http://localhost:8081/employee/info
//http://localhost:8080/employee/xyz  invalid
//http://localhost:8080/employee/info