package com.wipro.wsa17.service;

import com.wipro.wsa17.entity.GroceryItem;
import com.wipro.wsa17.repo.GroceryItemRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class GroceryItemServiceTest {

    @Mock
    private GroceryItemRepository repo;

    @InjectMocks
    private GroceryItemService service;

    public GroceryItemServiceTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetById() {
        GroceryItem item = new GroceryItem();
        item.setId(1L);
        item.setName("Rice");
        when(repo.findById(1L)).thenReturn(Optional.of(item));

        GroceryItem result = service.getById(1L);
        assertEquals("Rice", result.getName());
    }

    @Test
    void testAddItem() {
        GroceryItem item = new GroceryItem();
        item.setName("Milk");
        when(repo.save(item)).thenReturn(item);

        GroceryItem saved = service.addItem(item);
        assertEquals("Milk", saved.getName());
    }
}
