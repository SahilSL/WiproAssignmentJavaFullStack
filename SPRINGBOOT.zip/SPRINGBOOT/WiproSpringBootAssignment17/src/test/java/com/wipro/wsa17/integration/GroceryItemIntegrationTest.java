package com.wipro.wsa17.integration;

import com.wipro.wsa17.entity.GroceryItem;
import com.wipro.wsa17.repo.GroceryItemRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class GroceryItemIntegrationTest {

    @Autowired
    private GroceryItemRepository repo;

    @Test
    void testCreateAndRetrieve() {
        GroceryItem item = new GroceryItem();
        item.setName("Sugar");
        item.setQuantity(2);
        item.setPrice(50);
        repo.save(item);

        GroceryItem found = repo.findById(item.getId()).orElse(null);
        assertNotNull(found);
        assertEquals("Sugar", found.getName());
    }
}
