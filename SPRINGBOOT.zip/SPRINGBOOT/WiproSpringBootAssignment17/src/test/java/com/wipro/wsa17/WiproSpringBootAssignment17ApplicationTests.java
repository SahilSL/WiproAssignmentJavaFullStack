package com.wipro.wsa17;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproSpringBootAssignment17ApplicationTests {

	@Test
	void contextLoads() {
	}

}
