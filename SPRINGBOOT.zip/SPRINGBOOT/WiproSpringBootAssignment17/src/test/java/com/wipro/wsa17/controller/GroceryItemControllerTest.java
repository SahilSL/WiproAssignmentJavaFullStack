package com.wipro.wsa17.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.wsa17.entity.GroceryItem;
import com.wipro.wsa17.service.GroceryItemService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(GroceryItemController.class)
public class GroceryItemControllerTest {

    @Autowired
    private MockMvc mockMvc;

    //@MockBean
    private GroceryItemService service;

    @Autowired
    private ObjectMapper mapper;

    @Test
    void testGetAll() throws Exception {
        GroceryItem item = new GroceryItem();
        item.setName("Bread");
        Mockito.when(service.getAll()).thenReturn(List.of(item));

        mockMvc.perform(get("/api/grocery"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Bread"));
    }
}
