package com.wipro.wsa17.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class GroceryItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Name is required")
    private String name;

    @Min(value = 1, message = "Quantity must be at least 1")
    private int quantity;

    @Positive(message = "Price must be greater than 0")
    private double price;

  
    public Long getId() { 
return id; 
}
    public void setId(Long id) { 
this.id = id; 
}

    public String getName() { 
return name; 
}
    public void setName(String name) { 
this.name = name; 
}

    public int getQuantity() { 
return quantity; 
}
    public void setQuantity(int quantity) { 
this.quantity = quantity; 
}

    public double getPrice() { 
return price; 
}
    public void setPrice(double price) { 
this.price = price; 
}
}
