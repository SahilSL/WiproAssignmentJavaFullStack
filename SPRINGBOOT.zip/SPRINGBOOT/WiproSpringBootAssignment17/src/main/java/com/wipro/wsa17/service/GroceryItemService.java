package com.wipro.wsa17.service;

import com.wipro.wsa17.entity.GroceryItem;
import com.wipro.wsa17.repo.GroceryItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroceryItemService {

    @Autowired
    private GroceryItemRepository repo;

    public List<GroceryItem> getAll() {
        return repo.findAll();
    }

    public GroceryItem getById(Long id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Item not found"));
    }

    public GroceryItem addItem(GroceryItem item) {
        return repo.save(item);
    }

    public GroceryItem updateItem(Long id, GroceryItem item) {
        GroceryItem existing = getById(id);
        existing.setName(item.getName());
        existing.setQuantity(item.getQuantity());
        existing.setPrice(item.getPrice());
        return repo.save(existing);
    }

    public void deleteItem(Long id) {
        repo.deleteById(id);
    }
}
