package com.wipro.wsa17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment17Application {

	public static void main(String[] args) {
		SpringApplication.run(WiproSpringBootAssignment17Application.class, args);
	}

}

//http://localhost:8080/api/grocery
/*{
  "name": "Rice",
  "quantity": 5,
  "price": 110
}*/

//http://localhost:8080/api/grocery/1