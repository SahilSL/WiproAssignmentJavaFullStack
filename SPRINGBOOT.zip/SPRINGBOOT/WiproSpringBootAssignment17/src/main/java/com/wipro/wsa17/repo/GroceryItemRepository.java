package com.wipro.wsa17.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.wipro.wsa17.entity.GroceryItem;

public interface GroceryItemRepository extends JpaRepository<GroceryItem, Long> {
}
