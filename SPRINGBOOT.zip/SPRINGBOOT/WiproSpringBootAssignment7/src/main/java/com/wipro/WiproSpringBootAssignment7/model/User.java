package com.wipro.WiproSpringBootAssignment7.model;

import jakarta.validation.constraints.*;
import java.util.List;

public class User {

    @NotBlank(message = "{user.firstName.notblank}")
    @Size(min = 3, max = 30, message = "{user.firstName.size}")
    private String firstName;

    @NotBlank(message = "{user.lastName.notblank}")
    @Size(min = 3, max = 30, message = "{user.lastName.size}")
    private String lastName;

    @NotBlank(message = "{user.gender.notblank}")
    private String gender;

    @NotBlank(message = "{user.dob.notblank}")
    private String dob;

    @NotBlank(message = "{user.email.notblank}")
    @Email(message = "{user.email.invalid}")
    private String email;

    @NotBlank(message = "{user.section.notblank}")
    private String section;

    @NotBlank(message = "{user.country.notblank}")
    private String country;

    private boolean firstAttempt;

    @NotNull(message = "{user.subjects.notnull}")
    @Size(min = 1, message = "{user.subjects.min}")
    private List<String> subjects;

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }


    public String getDob() {
        return dob;
    }
    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getSection() {
        return section;
    }
    public void setSection(String section) {
        this.section = section;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }

    public boolean isFirstAttempt() {
        return firstAttempt;
    }
    public void setFirstAttempt(boolean firstAttempt) {
        this.firstAttempt = firstAttempt;
    }
    public List<String> getSubjects() {
        return subjects;
    }
    public void setSubjects(List<String> subjects) {
        this.subjects = subjects;
    }
}