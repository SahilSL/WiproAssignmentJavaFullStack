package com.wipro.WiproSpringBootAssignment7.controller;
import com.wipro.WiproSpringBootAssignment7.model.User;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@Controller
public class UserController {

    @GetMapping("/")
    public String showForm(Model model) {
        model.addAttribute("user", new User());

        List<String> countries = Arrays.asList("INDIA", "CANADA", "USA", "UK");
        List<String> subjects = Arrays.asList("Physics", "Chemistry", "Life Science", "Political Science", "Math");

        model.addAttribute("countries", countries);
        model.addAttribute("subjects", subjects);

        return "enrollmentForm";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("user") User user,
                           BindingResult result,
                           Model model) {
        if (result.hasErrors()) {
            model.addAttribute("countries", Arrays.asList("INDIA", "CANADA", "USA", "UK"));
            model.addAttribute("subjects", Arrays.asList("Physics", "Chemistry", "Life Science", "Political Science", "Math"));
            return "enrollmentForm";
        }
        return "success";
    }
}