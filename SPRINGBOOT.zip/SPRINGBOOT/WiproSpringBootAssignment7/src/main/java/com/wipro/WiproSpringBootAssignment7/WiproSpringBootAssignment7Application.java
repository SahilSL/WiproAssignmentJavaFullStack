package com.wipro.WiproSpringBootAssignment7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment7Application {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment7Application.class, args);
    }
}