package com.wipro.WiproSpringBootAssignment7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproSpringBootAssignment7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
