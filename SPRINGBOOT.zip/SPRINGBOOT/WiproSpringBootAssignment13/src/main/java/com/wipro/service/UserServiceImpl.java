
package com.wipro.service;

import com.wipro.entity.User;
import com.wipro.repository.UserRepository;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository repo;

    public UserServiceImpl(UserRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<User> getAllUsers() { 
return repo.findAll(); 
}

    @Override
    public User getUserById(Long id) { 
return repo.findById(id).orElse(null); 
}

    @Override
    public User createUser(User user) { 
return repo.save(user); 
}

    @Override
    public User updateUser(Long id, User user) {
        User existing = repo.findById(id).orElse(null);
        if (existing != null) {
            existing.setName(user.getName());
            existing.setAge(user.getAge());
            existing.setSalary(user.getSalary());
            return repo.save(existing);
        }
        return null;
    }

    @Override
    public void deleteUser(Long id) { 
repo.deleteById(id); 
}
}
