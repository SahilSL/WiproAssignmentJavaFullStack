package com.wipro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication 
public class WiproSpringBootAssignment13Application {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment13Application.class, args);
    }
}

/*
 PT:
 http://localhost:8080/users
 
 
 */