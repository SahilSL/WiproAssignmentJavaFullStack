package com.wipro.WiproSpringBootAssignment13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproSpringBootAssignment13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
