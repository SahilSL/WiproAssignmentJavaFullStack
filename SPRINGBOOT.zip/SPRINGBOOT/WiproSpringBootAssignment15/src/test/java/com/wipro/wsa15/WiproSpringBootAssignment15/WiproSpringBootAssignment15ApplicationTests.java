package com.wipro.wsa15.WiproSpringBootAssignment15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproSpringBootAssignment15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
