package com.wipro.wsa15.controller;

import com.wipro.wsa15.entity.Client;
import com.wipro.wsa15.service.ClientService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class ClientController {
    private final ClientService service;

    public ClientController(ClientService service) { this.service = service; }

    @GetMapping("/")
    public String viewHomePage(Model model) {
        model.addAttribute("clients", service.getAllClients());
        return "index";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("client", new Client());
        return "add-client";
    }

    @PostMapping("/save")
    public String saveClient(@ModelAttribute("client") Client client) {
        if (client.getId() != null) {
            Client existing = service.getById(client.getId());
            existing.setName(client.getName());
            existing.setEmail(client.getEmail());
            existing.setPhone(client.getPhone());
            existing.setAddress(client.getAddress());
            service.save(existing);
        } else {
            service.save(client);
        }
        return "redirect:/";
    }


    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        model.addAttribute("client", service.getById(id));
        return "add-client";
    }

    @GetMapping("/delete/{id}")
    public String deleteClient(@PathVariable Long id) {
        service.delete(id);
        return "redirect:/";
    }
}
