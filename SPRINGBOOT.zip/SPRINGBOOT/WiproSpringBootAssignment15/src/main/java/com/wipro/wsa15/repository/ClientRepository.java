package com.wipro.wsa15.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.wipro.wsa15.entity.Client;

public interface ClientRepository extends JpaRepository<Client, Long> {}
