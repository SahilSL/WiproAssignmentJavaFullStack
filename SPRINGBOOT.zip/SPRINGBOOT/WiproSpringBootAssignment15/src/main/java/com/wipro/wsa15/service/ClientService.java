package com.wipro.wsa15.service;

import com.wipro.wsa15.entity.Client;
import com.wipro.wsa15.repository.ClientRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ClientService {
    private final ClientRepository repo;

    public ClientService(ClientRepository repo) {
        this.repo = repo;
    }
    


    public List<Client> getAllClients() { return repo.findAll(); }
    public void save(Client client) { repo.save(client); }
    public Client getById(Long id) { return repo.findById(id).orElse(null); }
    public void delete(Long id) { repo.deleteById(id); }
}
