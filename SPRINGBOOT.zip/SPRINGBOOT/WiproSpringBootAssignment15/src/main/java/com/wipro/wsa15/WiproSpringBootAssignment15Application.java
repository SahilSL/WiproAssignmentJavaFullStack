package com.wipro.wsa15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment15Application {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment15Application.class, args);
    }
}
