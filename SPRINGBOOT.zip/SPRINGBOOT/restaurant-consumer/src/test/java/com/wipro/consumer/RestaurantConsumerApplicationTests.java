package com.wipro.consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
