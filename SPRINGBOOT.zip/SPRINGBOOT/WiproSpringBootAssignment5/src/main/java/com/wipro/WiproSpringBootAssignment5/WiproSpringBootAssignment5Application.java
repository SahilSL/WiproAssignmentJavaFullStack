package com.wipro.WiproSpringBootAssignment5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment5Application {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment5Application.class, args);
    }
}

// http://localhost:8080/example/test
// http://localhost:8080/example/test2