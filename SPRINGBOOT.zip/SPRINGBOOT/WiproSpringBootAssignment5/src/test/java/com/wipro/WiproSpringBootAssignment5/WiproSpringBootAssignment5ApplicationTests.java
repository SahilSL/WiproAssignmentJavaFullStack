package com.wipro.WiproSpringBootAssignment5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproSpringBootAssignment5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
