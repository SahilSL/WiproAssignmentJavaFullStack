package com.wipro.assignment2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAssignment2Application implements CommandLineRunner {

    @Autowired
    private ValueReader valueReader;

    public static void main(String[] args) {
        SpringApplication.run(SpringbootAssignment2Application.class, args);
    }

    @Override
    public void run(String... args) {
        valueReader.displayValues();
    }
}
