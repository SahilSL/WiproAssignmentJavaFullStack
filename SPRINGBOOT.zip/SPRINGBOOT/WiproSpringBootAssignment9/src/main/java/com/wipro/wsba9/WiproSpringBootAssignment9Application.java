package com.wipro.wsba9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment9Application {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment9Application.class, args);
    }
}
// http://localhost:8080/bookXYZ