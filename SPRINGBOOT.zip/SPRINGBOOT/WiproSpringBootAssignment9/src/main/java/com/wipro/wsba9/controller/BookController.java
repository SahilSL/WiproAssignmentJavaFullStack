package com.wipro.wsba9.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.wsba9.model.Book;

import java.util.ArrayList;
import java.util.List;

@RestController
public class BookController {

    @GetMapping(value = "/bookXYZ", produces = "application/xml")
    public List<Book> getBooks() {
        List<Book> books = new ArrayList<>();
        books.add(new Book(101, "Java Tutorials", "Krishna"));
        books.add(new Book(102, "Spring Tutorials", "Mahesh"));
        books.add(new Book(103, "Angular Tutorials", "Shiva"));
        return books;
    }
}
