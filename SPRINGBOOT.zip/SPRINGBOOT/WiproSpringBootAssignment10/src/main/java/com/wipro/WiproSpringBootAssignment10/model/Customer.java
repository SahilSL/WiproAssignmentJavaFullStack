package com.wipro.WiproSpringBootAssignment10.model;

import jakarta.validation.constraints.*;
import org.springframework.format.annotation.DateTimeFormat;
import java.util.Date;

public class Customer {

    @Size(min = 2, max = 30, message = "{customer.name.size}")
    private String name;

    @NotBlank(message = "{customer.email.required}")
    @Email
    private String email;

    @Min(value = 18, message = "{customer.age.invalid}")
    private int age;

    @NotBlank(message = "{customer.gender.required}")
    private String gender;

    @NotNull(message = "{customer.birthday.required}")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birthday;

    @Pattern(regexp = "^(\\d{10}|\\d{3}-\\d{3}-\\d{4}|x\\d{4})$", message = "{customer.phone.invalid}")
    private String phone;

    // Getters & Setters
    public String getName() { 
		return name; 
		}
    public void setName(String name) { 
		this.name = name; 
		}

    public String getEmail() { 
		return email;
		 }
    public void setEmail(String email) { 
		this.email = email; 
		}

    public int getAge() { 
		return age; 
		}
    public void setAge(int age) { 
		this.age = age; 
		}

    public String getGender() { 
		return gender; 
		}
    public void setGender(String gender) { 
		this.gender = gender; 
		}

    public Date getBirthday() { 
		return birthday; 
		}
    public void setBirthday(Date birthday) { 
		this.birthday = birthday; 
		}
		

    public String getPhone() { 
		return phone; 
		}
    public void setPhone(String phone) { 
		this.phone = phone; 
		}
}
