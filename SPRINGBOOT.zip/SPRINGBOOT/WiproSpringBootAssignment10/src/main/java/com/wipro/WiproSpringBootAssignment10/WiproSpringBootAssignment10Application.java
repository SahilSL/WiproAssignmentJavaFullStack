package com.wipro.WiproSpringBootAssignment10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment10Application {

	public static void main(String[] args) {
		SpringApplication.run(WiproSpringBootAssignment10Application.class, args);
	}

}
//http://localhost:8080/customer