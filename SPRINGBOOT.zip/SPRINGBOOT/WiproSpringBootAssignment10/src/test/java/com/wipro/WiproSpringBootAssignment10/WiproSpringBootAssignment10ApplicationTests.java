package com.wipro.WiproSpringBootAssignment10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproSpringBootAssignment10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
