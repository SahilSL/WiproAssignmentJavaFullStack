function showMessage() {
    alert("Hello! This is JavaScript and working in sccessfully");
}
