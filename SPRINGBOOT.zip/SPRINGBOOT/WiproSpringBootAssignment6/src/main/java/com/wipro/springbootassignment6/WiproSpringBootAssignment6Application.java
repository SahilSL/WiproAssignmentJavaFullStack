package com.wipro.springbootassignment6;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringBootAssignment6Application {
    public static void main(String[] args) {
        SpringApplication.run(WiproSpringBootAssignment6Application.class, args);
    }
}