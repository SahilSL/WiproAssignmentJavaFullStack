package com.wipro.springbootassignment6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproSpringBootAssignment6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
