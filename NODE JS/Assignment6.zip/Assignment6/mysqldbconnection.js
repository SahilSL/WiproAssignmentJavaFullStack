const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root', 
  password: 'Sahil@2502',         
  database: 'stock_market_lab'
});


connection.connect((err) => {
  if (err) {
    console.error('MySQL connection failed:', err.message);
    return;
  }
  console.log('Connected to MySQL (stock_market_lab)');
});

module.exports = connection;
