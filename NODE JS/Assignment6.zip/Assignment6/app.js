const connection = require('./mysqldbconnection');

function addStock(symbol, companyName, price, volume, callback) {
  const query = 'INSERT INTO stocks (symbol, companyName, price, volume) VALUES (?, ?, ?, ?)';
  connection.query(query, [symbol, companyName, price, volume], (err, result) => {
    if (err) return callback(err);
    console.log(`Added stock with ID: ${result.insertId}`);
    callback(null, result.insertId);
  });
}

function listStocks(callback) {
  connection.query('SELECT * FROM stocks', (err, results) => {
    if (err) return callback(err);
    console.log('All Stocks:', results);
    callback(null, results);
  });
}

function updateStockPriceAndVolume(id, price, volume, callback) {
  const query = 'UPDATE stocks SET price = ?, volume = ? WHERE id = ?';
  connection.query(query, [price, volume, id], (err, result) => {
    if (err) return callback(err);
    console.log(`Updated records: ${result.affectedRows}`);
    callback(null, result.affectedRows);
  });
}

function deleteStock(id, callback) {
  const query = 'DELETE FROM stocks WHERE id = ?';
  connection.query(query, [id], (err, result) => {
    if (err) return callback(err);
    console.log(`Deleted records: ${result.affectedRows}`);
    callback(null, result.affectedRows);
  });
}

addStock('AAPL', 'Apple Inc.', 175.50, 1000, (err, insertedId) => {
  if (err) return console.error('Add error:', err);

  listStocks((err, stocks) => {
    if (err) return console.error('List error:', err);

    updateStockPriceAndVolume(insertedId, 180.00, 1200, (err, updatedCount) => {
      if (err) return console.error('Update error:', err);

      deleteStock(insertedId, (err, deletedCount) => {
        if (err) return console.error('Delete error:', err);

        connection.end((err) => {
          if (err) return console.error('Error closing connection:', err.message);
          console.log('MySQL connection closed');
        });
      });
    });
  });
});
