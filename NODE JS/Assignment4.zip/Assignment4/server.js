// server.js

const net = require('net');

// Jewellery inventory in memory (shared across all clients)
let jewelleryStock = [
  { id: 1, name: "Gold Ring", quantity: 5, price: 15000 },
  { id: 2, name: "Silver Necklace", quantity: 3, price: 5000 }
];

// Create the TCP server
const server = net.createServer((socket) => {
  console.log('Client connected');

  // Handle incoming data from client
  socket.on('data', (data) => {
    const message = data.toString().trim(); // Clean input
    const [command, ...args] = message.split(' ');

    switch (command.toUpperCase()) {
      case 'LIST':
        // List all jewellery items
        if (jewelleryStock.length === 0) {
          socket.write('No items in stock.\n');
        } else {
          jewelleryStock.forEach(item => {
            socket.write(`ID: ${item.id}, Name: ${item.name}, Quantity: ${item.quantity}, Price: ${item.price}\n`);
          });
        }
        break;

      case 'ADD':
        // Format: ADD <id> <name (single-word)> <quantity> <price>
        if (args.length < 4) {
          socket.write('Invalid ADD command. Use: ADD <id> <name> <quantity> <price>\n');
        } else {
          const [idStr, name, quantityStr, priceStr] = args;
          const id = parseInt(idStr);
          const quantity = parseInt(quantityStr);
          const price = parseFloat(priceStr);

          if (isNaN(id) || isNaN(quantity) || isNaN(price)) {
            socket.write('Invalid data types. Ensure ID, quantity, and price are numbers.\n');
          } else {
            jewelleryStock.push({ id, name, quantity, price });
            socket.write('Jewellery item added successfully!\n');
          }
        }
        break;

      case 'EXIT':
        socket.write('Client disconnected.\n');
        socket.end(); // Close connection
        break;

      default:
        socket.write('Unknown command. Use LIST, ADD, or EXIT.\n');
    }
  });

  // Handle connection close
  socket.on('end', () => {
    console.log('Client disconnected');
  });

  // Handle socket errors
  socket.on('error', (err) => {
    console.error('Socket error:', err.message);
  });
});

// Start server on port 5000
server.listen(5000, () => {
  console.log('TCP Server started on port 5000');
});
