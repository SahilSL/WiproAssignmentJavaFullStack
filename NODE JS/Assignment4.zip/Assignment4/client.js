// client.js

const net = require('net');
const readline = require('readline');

// Connect to TCP server
const client = new net.Socket();
client.connect(5000, '127.0.0.1', () => {
  console.log('Connected to server.');
  console.log('Type commands: LIST | ADD <id> <name> <quantity> <price> | EXIT');
});

// Set up readline interface for user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Listen for user input and send to server
rl.on('line', (input) => {
  client.write(input);
});

// Display server response
client.on('data', (data) => {
  console.log(`Server: ${data.toString()}`);
});

// Handle client disconnect
client.on('end', () => {
  console.log('Disconnected from server.');
  rl.close();
});

// Handle errors
client.on('error', (err) => {
  console.error('Connection error:', err.message);
  rl.close();
});
