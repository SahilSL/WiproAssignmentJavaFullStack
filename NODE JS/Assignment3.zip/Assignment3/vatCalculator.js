// Default VAT percentage
let vatPercentage = 3;

// Function to set a custom VAT percentage 
function setVATPercentage(percent) {
  vatPercentage = percent;
}

// Function to calculate VAT and total price
function calculateVAT(price) {
  // Calculate the VAT amount
  const vat = (price * vatPercentage) / 100;

  // Calculate total price (original price + VAT)
  const totalPrice = price + vat;

  return {
    vat,
    totalPrice
  };
}

// Export the functions
module.exports = {
  calculateVAT,
  setVATPercentage 
};
