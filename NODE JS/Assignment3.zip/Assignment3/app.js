const vatCalculator = require('./vatCalculator');

// Optional: Set a custom VAT rate 
// vatCalculator.setVATPercentage(5);

// Define an array of jewellery items 
const jewelleryItems = [
  { id: 1, name: "Gold Necklace", price: 50000 },
  { id: 2, name: "Diamond Ring", price: 75000 },
  { id: 3, name: "Silver Bracelet", price: 20000 }
];

// Loop through each item and calculate VAT
jewelleryItems.forEach(item => {
  // Destructure the returned VAT and total price
  const { vat, totalPrice } = vatCalculator.calculateVAT(item.price);

  // Display the details
  console.log(`Jewellery ID: ${item.id}`);
  console.log(`Name: ${item.name}`);
  console.log(`Price: ${item.price}`);
  console.log(`VAT (3%): ${vat}`);
  console.log(`Total Price: ${totalPrice}`);
  console.log('-----------------------------');
});
