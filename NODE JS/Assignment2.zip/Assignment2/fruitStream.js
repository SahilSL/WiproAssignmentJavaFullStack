// Import required core Node.js modules
const fs = require('fs');          // For file system operations
const path = require('path');      // For handling file paths

// Define file paths using path.join to ensure cross-platform compatibility
const fruitsFile = path.join(__dirname, 'fruits.txt');
const fruitsCopyFile = path.join(__dirname, 'fruits_copy.txt');

// Define an array of fruit objects to write to the file
const fruits = [
  { id: 1, name: 'Apple', color: 'Red', price: 120 },
  { id: 2, name: 'Banana', color: 'Yellow', price: 40 },
  { id: 3, name: 'Mango', color: 'Orange', price: 150 }
];

// writable Stream  - Create a writable stream to write data into 'fruits.txt'
const writeStream = fs.createWriteStream(fruitsFile);

// Event listener: Triggered when all data has been flushed to the file
writeStream.on('finish', () => {
  console.log('Data written to fruits.txt successfully.\n');

  // Call function to read the file next
  readFruits();
});

// Event listener: Handles any errors that occur while writing
writeStream.on('error', (err) => {
  console.error('Write error:', err);
});

// Write each fruit object as a JSON string followed by a newline to the file
fruits.forEach(fruit => {
  writeStream.write(JSON.stringify(fruit) + '\n');
});

// Signal the end of writing
writeStream.end();

// Readable Stream with Events
// Function to read from 'fruits.txt' using a readable stream
function readFruits() {
  console.log('Reading fruits.txt using stream...');

  // Create a readable stream and set encoding to 'utf8' to get string chunks
  const readStream = fs.createReadStream(fruitsFile, { encoding: 'utf8' });

  let leftover = '';  // Buffer to hold partial data between chunks

  // 'data' event: triggered when a chunk of data is available
  readStream.on('data', (chunk) => {
    leftover += chunk;                // Append the new chunk to leftover
    let lines = leftover.split('\n'); // Split by newline to get complete lines
    leftover = lines.pop();           // Save the last partial line for next chunk

    // Process each complete line
    lines.forEach(line => {
      if (line.trim()) {
        try {
          const fruit = JSON.parse(line); // Parse JSON string
          // Display fruit details in formatted way
          console.log(`Fruit ID: ${fruit.id}, Name: ${fruit.name}, Color: ${fruit.color}, Price: ${fruit.price}`);
        } catch (e) {
          console.error('Invalid JSON:', e.message);
        }
      }
    });
  });

  // 'end' event: triggered when all data has been read
  readStream.on('end', () => {
    // Handle the final leftover line if it exists
    if (leftover.trim()) {
      try {
        const fruit = JSON.parse(leftover);
        console.log(`Fruit ID: ${fruit.id}, Name: ${fruit.name}, Color: ${fruit.color}, Price: ${fruit.price}`);
      } catch (e) {
        console.error('Invalid JSON on end:', e.message);
      }
    }

    console.log('\nFinished reading fruits.txt.\n');

    // After reading is done, copy the file
    copyFruits();
  });

  // 'error' event: triggered if there is an error while reading
  readStream.on('error', (err) => {
    console.error('Read error:', err);
  });
}

// Pipe Streams
// Function to copy contents of 'fruits.txt' to 'fruits_copy.txt' using pipe
function copyFruits() {
  // Create readable and writable streams
  const readStream = fs.createReadStream(fruitsFile);
  const writeStream = fs.createWriteStream(fruitsCopyFile);

  // Pipe data from readStream directly into writeStream
  readStream.pipe(writeStream);

  // Event listener for when writing to fruits_copy.txt is finished
  writeStream.on('finish', () => {
    console.log('Content copied to fruits_copy.txt using pipe.');
  });

  // Error handling for writing
  writeStream.on('error', (err) => {
    console.error('Copy error:', err);
  });
}
