// server.js

const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static HTML form
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle form submission
app.post('/submit', (req, res) => {
  const {
    trackingId,
    senderName,
    receiverName,
    pickupAddress,
    deliveryAddress,
    weight
  } = req.body;

  // Validate all fields
  if (!trackingId || !senderName || !receiverName || !pickupAddress || !deliveryAddress || !weight) {
    return res.send('All fields are required.');
  }

  // Convert weight to number and calculate cost
  const parsedWeight = parseFloat(weight);
  const deliveryCost = 50 + (parsedWeight * 20);

  // Respond with confirmation
  res.send(`
    <h2>Courier Booking Confirmed</h2>
    <p><strong>Courier Tracking ID:</strong> ${trackingId}</p>
    <p><strong>Sender:</strong> ${senderName}</p>
    <p><strong>Receiver:</strong> ${receiverName}</p>
    <p><strong>Pickup:</strong> ${pickupAddress}</p>
    <p><strong>Delivery:</strong> ${deliveryAddress}</p>
    <p><strong>Weight:</strong> ${parsedWeight} kg</p>
    <p><strong>Delivery Cost:</strong> ₹${deliveryCost}</p>
  `);
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
